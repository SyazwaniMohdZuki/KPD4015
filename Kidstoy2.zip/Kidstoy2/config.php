<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed..."); //padam kata laluan dan cuba uji lari sistem semula.
?>
