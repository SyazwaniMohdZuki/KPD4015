<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed..."); //padam :3306 pada localhost dan padam password
?>
