<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
//3306 dan padam password//
?>
